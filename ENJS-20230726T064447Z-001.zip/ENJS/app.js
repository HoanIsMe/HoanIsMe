const express = require('express');
 const path = require('path');
 const ejs = require('ejs');
 const app = express();
 const bodyParser = require("body-parser");
 app.set('views', path.join(__dirname, '/views'));
 app.set('views engine', 'ejs');
 app.engine('html',ejs.renderFile);
 app.use(bodyParser.json());
 app.use(bodyParser.urlencoded({extended:true}));
 app.use(express.static(path.join(__dirname, '/public', )));
 
 let users = [
    {'fullname': 'John', 'email': 'john@example.com ','phone' : '123'},
    {'fullname': 'Van Anh', 'email': 'Vananh@example.com ','phone' : '888'},
];
 app.get('/', (req, res) => {
     res.render('index.html',{"xxx":users, "inform":""});
 });
//  app.get('/search/:keyword', function (req, res) {
//     let keyword = req.params.keyword;
//     let result = [];
//     let inform = "Result seaching by Full Name";
//     if (keyword.length > 0){
//         //search 
//         users.map(users => {
//             if (users.fullname.includes(keyword)){
//                 result.push(users);
//             }
//             if(result.length == 0){
//                 inform = "Not Found"
//             }
//         })
//     }
//     res.render("index.html",{"xxx":result, "inform": inform})
//  });
// app.get("/user/search",(req,res)=>{
//     res.render("/user/search.html",{"users":'', "fname": ''});
// });
app.post("/user/search", function(req,res){
    let fname = req.body.fname;
    let result = [];
    
    if(fname.length > 0){
       users.map(user => {
        if(user.fullname.toLocaleLowerCase().includes(fname.toLocaleLowerCase())){
            result.push(user)
        }
       });
    }
    if(result.length == 0){
        res.send("Not Found!")
    }
    res.render("index.html",{"xxx":result,  "inform":""});
   
    
});
app.get("/user/add",(req,res)=>{
    res.render("/user/add.html");
});
app.post("/user/add",function(req,res){
    let fullname = req.body.fullname;
    let email = req.body.email;
    let phone =  req.body.phone;
    if(fullname.length >0&&email.length>0&&phone>0){
        let newUser = {"fullname":fullname, "email":email, "phone":phone};
        users.push(newUser);;
    }
    res.redirect("/");
});
 app.listen(3000);