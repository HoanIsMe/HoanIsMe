const mysql =require("mysql");
const config = {
  host: 'localhost',
  user: 'thodepzai',
  password: 'Huutho2003',
  database: 'c2108gdb',
}
const Db= mysql.createConnection(config);
Db.connect((err)=>{
    if(err) console.log(err);
    console.log("MySQL connected!");
})
module.exports = Db;