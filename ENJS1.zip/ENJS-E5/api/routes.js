const routes =(app,Ticker)=>{
app.route("/Api/Ticker/AddNew").post(Ticker.AddNew);
app.route("/Api/Ticker/Add").get(Ticker.Add);
app.route("/Api/Ticker/Listing").get(Ticker.List);
app.route("/Api/Ticker/Search").post(Ticker.Search);
app.route("/Api/Ticker/Delete").post(Ticker.Delete);
};
module.exports=routes;


