const Db = require("../Model/Db");
// const mysql = require('mysql');

// const connection = mysql.createConnection({
//   host: 'localhost',
//   user: 'thodepzai',
//   password: 'Huutho2003',
//   database: 'c2108gdb',
// });

// exports.AddNew = (req, res) => {
//   // Handle adding new Ticker here
//   const query = 'INSERT INTO Ticker (Code, Name) VALUES (?, ?)';
//     connection.query(query, [Code, Name], function(error, results, ) {
//       if (error) {
//         // Handle error
//         return res.status(500).json({ error: 'Database error' });
//       }

//       // Return success response
//       res.json({ success: true });
//       res.send("index.html",{"tikser" : results});
    
//   });
// };

// exports.List = (req, res) => {
//   const query = 'SELECT * FROM Ticker';
//     connection.query(query, function(error, results) {
//       if (error) {
//         // Handle error
//         return res.status(500).json({ error: 'Database error' });
//       }
//       // Return the list of tickers
//       res.send("index.html",{"ticker" : results});
//     });
//   };
module.exports={
  List:(req,res)=>{
    let sql =" SELECT *FROM ticker WHERE 1=1"
    Db.query(sql,(err,rs)=>{
      if(err) throw err
      res.render("../view/index.html",{"tickers":rs}) 
      // console.log(rs);
    })
  },
  Add:(req,res)=>{
    res.render("../view/add.html");
  }
  ,
  AddNew:(req,res)=>{
    if (!/^[A-Z]{2,4}$/.test(req.body.Code)) {
      return res.render("../view/error.html");
    }
    if (!/^[A-Za-z]+$/.test(req.body.Name)) {
      return res.render("../view/error.html");
    }
    let sql ="INSERT INTO ticker (Code, Name) VALUES (?,?)"
    Db.query(sql, [req.body.Code,req.body.Name], function(error, results) {
            if (error) {
              // Handle error
              return res.status(500).json({ error: 'Database error' });
            }
         res.redirect("/Api/Ticker/Listing");
  })
},
Search:(req,res)=>{
  let keyword = req.body.search;
  let sql = 'SELECT * FROM ticker WHERE Code = ? OR Name =?';
  
  if(keyword){
  Db.query(sql, [keyword,keyword], function(error, result)  {
    if (error) throw error;
    res.render("../view/index.html",{"tickers":result});
    if(result.length==0){
      res.send("Not Found");
    }
  })
  }
},Delete:(req,res)=>{

  let sql = 'DELETE FROM ticker WHERE id = ?';
  Db.query(sql,[req.body.Id], function (err, result) {
    if (err) throw err;
    res.redirect("/Api/Ticker/Listing");
  });

}
}