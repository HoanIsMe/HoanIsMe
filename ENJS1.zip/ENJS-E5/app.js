const express = require("express");
const path = require("path");
const ejs = require("ejs");
const app = express();
app.set("views", path.join(__dirname + "/view"));

app.set("view engine", "ejs");

app.engine("html", ejs.renderFile);

app.use(express.static(path.join(__dirname, "/public")));

app.use(express.json()) // for parsing application/json
app.use(express.urlencoded({ extended: true })) // for parsing application/x-www-form-urlencoded
// // Importing required modules
// const express = require('express');
// const bodyParser = require('body-parser');
// const mysql = require('mysql');

// // Creating connection to MySQL database
// const connection = mysql.createConnection({
//   server: 'Turtle\\SQLEXPRESS',
//   user: 'Turtle\\Admin',
//   password: '',
//   database: 'Tho'
// });

// // // Connecting to MySQL database
// // connection.connect((err) => {
// //   if (err) throw err;
// //   console.log('Connected to MySQL database!');
// // });

// // Creating express app
// const app = express();

// // Parsing request body
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));

// // Adding new ticker
// app.post('/Api/Ticker/AddNew', (req, res) => {
//   const { Code, Name } = req.body;
//   const sql = `INSERT INTO Ticker (Code, Name) VALUES ('${Code}', '${Name}')`;
//   connection.query(sql, (err, result) => {
//     if (err) throw err;
//     console.log(result);
//     res.send('Ticker added successfully!');
//   });
// });

// // Listing tickers
// app.get('/Api/Ticker/Listing', (req, res) => {
//   const sql = 'SELECT * FROM Ticker';
//   connection.query(sql, (err, result) => {
//     if (err) throw err;
//     console.log(result);
//     res.send(result);
//   });
// });

// // Starting server
// app.listen(3000, () => {
//   console.log('Server started on port 3000!');
// });
// const sql = require('mssql');

// const config = {
//   user: 'sa',
//   password: '12',
//   server: 'Turtle',
//   database: 'haoancut',
  
//   synchronize: true,
//   trustServerCertificate: true
// };

// sql.connect(config).then(() => {
//   console.log('Connected to database!');
// }).catch((err) => {
//   console.error('Error connecting to database: ', err);
// });
let Ticker =require("./controller/Ticker");
let Pricing =require("./controller/Pricing");
let routes = require("./api/routes");
let routes1 = require("./api/routes1");

// const routesFunction = routes.routes;
// const routes1Function = routes.routes1;

// ...

routes(app, Ticker);
routes1(app, Pricing);

app.listen(3000, function(){
    console.log("App started in port 3000");
});