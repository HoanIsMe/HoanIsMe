const Db = require("../Model/Db");
module.exports={
    SearchByTickerCode:(req,res)=>{
        Db.query('SELECT * FROM Pricing WHERE TickerId = (SELECT Id FROM Ticker WHERE Code = ?)', [req.body.Code], function (error, results) {
            if (error) throw error;
            res.render("../view/index2.html",{"pricings":results});
          });
        
    }
}