const routes1 =(app,Pricing)=>{
    app.route("/Api/Pricing/SearchByTickerCode").post(Pricing.SearchByTickerCode);
};
module.exports = routes1;