const express = require("express");
const path = require("path");
const ejs = require("ejs");
const bodyParser = require("body-parser");
const { info } = require("console");
const app = express();
app.set("views", path.join(__dirname + "/views"));
app.set("view engine", "ejs");
app.engine("html", ejs.renderFile);
app.use(express.static(path.join(__dirname,"public")));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
let users = [
   {"fullname": "Mr Bean", "email": "bean@gmail.com", "phone":"84253634747"},
   {"fullname":"Tho an cut", "email":"tho@gmail.com", "phone":"+123456789"},
   {"fullname":"Lan Anh", "email":"tho@gmail.com", "phone":"+123456789"},
   {"fullname":"My Anh", "email":"tho@gmail.com", "phone":"+123456789"}
];
app.get("/", function(req, res){
   res.render("index.html",{"xxx":users, "fname":""});
});
app.post("/user/search", function(req,res){
   let u = [];
   let fname = req.body.fullname;
   if(fname.length > 0){
      users.map(user =>{
         if(user.fullname.toUpperCase().includes(fname.toUpperCase())){
            u.push(user);
         }
      });
   }
   if( u.length == 0){
      res.send("Not found!");
   }
   res.render("index.html", {"xxx":u, "fname":fname});
});
app.get("/user/add", function(req,res){
   res.render("./users/add.html");
});
app.post("/user/add", function(req,res){
   let fullname = req.body.fullname;
   let email = req.body.email;
   let phone = req.body.phone;
   let newUser = {"fullname":fullname, "email":email, "phone":phone};
   users.push(newUser);
   res.redirect("/");
});
app.listen(3000);
