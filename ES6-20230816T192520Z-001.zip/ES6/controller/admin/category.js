import db from "../../model/mysqlconnection.js";
import {Router} from "express";
const categoryRouter = Router();
categoryRouter.get("/category/list",(req,res)=>{
    res.render("./admin/category/index.html");
});
export default categoryRouter;