//const express = require("express");
import express from "express";
import bodyParser from "body-parser";
import ejs from "ejs";
import {getGlobals} from "common-es";
import path from "path";
const {__dirname} = getGlobals(import.meta.url);
const app = express();
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
//set views engine
//path.join(__dirname,
app.set("views","views");
app.set("view engine","ejs");
app.engine("html",ejs.renderFile);


import category from "./controller/admin/category.js";
app.use("/admin",category);
app.get("/",(req,res)=>{
    console.log(res.statusCode);
    res.render("index.html");
})
app.listen(9000,function(){
    console.log("App started by port 9000");
})



