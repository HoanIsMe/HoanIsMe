create database shoppingonline;
use shoppingonline;

#Generate E-R Model
create table category(
	id int primary key auto_increment
    #SS001, AP002
    ,code char(5) not null
    , name varchar(150) not null
);
create table users(
	id int primary key auto_increment,
    fullname varchar(100) not null,
    code varchar(10) not null, #WH001
    phone varchar(30) not null,
    email varchar(150) not null
);
create table product(
	id int primary key auto_increment
    ,cat_id int 
    ,user_id int
    ,code varchar(20) not null
    ,name varchar(200) not null
    ,price double not null
    ,quantity int not null
    ,images text null
    ,description text null
    ,datetime_entered datetime default current_timestamp()
    ,datetime_last_updated datetime null
    ,foreign key references users(id)
    ,foreign key references category(id)
);