import mysql from "mysql";
const config={
    host:"localhost"
    ,user:"webapp"
    ,password:"1Q2w3e@#"
    ,database:"shoppingonline"
    ,port:3306
}
const dbmysql = mysql.createPool(config);
dbmysql.getConnection((err)=>{
    if(err) throw console.log("Not connected to MySQL Server Database");
});
export default dbmysql;