const express= require("express");
const path = require("path");
const ejs = require("ejs");
const app = express();
app.set("views", path.join(__dirname+"/views"));
app.set("view engine","ejs");
app.engine("html",ejs.renderFile);
app.use(express.static(path.join(__dirname,"/public")));

app.get("/", function(req,res){
    let users = [
        {"fullname": "Mr Bean", "email":"bean@gmail.com","phone":"+84253634747"}
        ,{"fullname":"Lan Anh", "email":"anhanh@hotmail.co","phone":"+12142363637347"}
    ];
    res.render("index.html",{"xxx":users});
});

app.listen(3000);