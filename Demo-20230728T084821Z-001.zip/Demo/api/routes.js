const routes = (app, controllerName)=>{
    app.route('/users/list')
    .get(controllerName.List);
    app.route("/users/add")
    .get(controllerName.Add);
    app.route("/users/addNew")
    .post(controllerName.AddNew);

    // app.route("/"+controllerName+"/:Id")
    // .get(controllerName.findById)
    // .put(controllerName.update)
    // .delete(controllerName.delete);

    app.route("/users/search/:keyword")
    .get(controllerName.SearchByName);
}
module.exports = routes;