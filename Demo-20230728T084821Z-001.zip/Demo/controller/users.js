const lsuser = [{"userName":"Mr Bean","email":"mrbean@gmail.com"},
                {"userName":"MrsLan","email":"lan@gmail.com"}];
module.exports = {
    List:(req,res)=>{
        res.render("index.html",{"users":lsuser ,"tile":"List Users"});
    },
    Add:(req, res)=>{
        res.render("./users/add.html");
    },
    AddNew:(req, res)=>{
        let username = req.body.username;
        let email = req.body.email;
        let newUser = {"userName":username,"email":email};
        lsuser.push(newUser);
        res.redirect("/users/list");
    },
    SearchByName:(req,res)=>{
        let keyword = req.params.keyword;
        var Users = [];
        //console.log(keyword);
        if(keyword.length>0){
            //console.log(keyword.length);
            lsuser.map(u=>{
                if(u.userName.includes(keyword)) {
                    return Users.push(u);
                }
            });
        }
        //console.log(user.userName);
        res.render("search.html",{"users":Users});

    }
    
}