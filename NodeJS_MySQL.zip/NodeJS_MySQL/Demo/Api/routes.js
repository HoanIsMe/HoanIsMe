const routes = function(app, controllername){
    app.route("/users/list")
    .get(controllername.List);
    app.route("/users/add")
    .get(controllername.Add)
    .post(controllername.AddNew);
    app.route('/users/search/:keyword')
    .get(controllername.SearchByName);
    app.route('/users/search')
    .post(controllername.SearchByNameByInput);
    app.route('/users/delete/:keyword')
    .get(controllername.Delete);
    app.route("/users/update/:keyword")
    .get(controllername.Update)
    .post(controllername.UpdateNew);

}
module.exports = routes;