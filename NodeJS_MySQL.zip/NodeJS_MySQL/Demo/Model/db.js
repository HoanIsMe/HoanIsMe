const mysql = require("mysql");
const config = {
    host: "localhost",
    user: "webapp",
    password: "Kientlt1705@",
    server: 'LAPTOP-1PVRHQV8',
    database:"shop",
    insecureAuth : true
}
const db = mysql.createConnection(config);
db.connect(function(err) {
    if (err) {
      console.error('error connecting: ' + err);
      return;
    }
   console.log('connected as id ' + db.threadId);
  });
module.exports = db;
//Fix: ER_NOT_SUPPORTED_AUTH_MODE
//ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password';