const db = require("../Model/db");
module.exports = {
    List:function(req,res){
        let sql = "SELECT * FROM ticker WHERE 1";
        db.query(sql, (err, rs)=>{
           // console.log(rs);
            if(err) throw err;
            res.render("./User/index.html", {"users":rs,"keyword":""});
        });
    },
    Add:(req,res)=>{
        res.render("./User/add.html");
    },
    AddNew:(req,res)=>{
        let Code = req.body.Code;
        let Name = req.body.Name;
        let newUser = {"Code":Code,"Name":Name};
        
        const ticketcodeRegex = /^[A-Z]{2,4}$/;
        const ticketnameRegex = /^[A-Za-z0-9 ]+$/;

            if(!ticketcodeRegex.test(Code)) {
                res.send("Vui lòng điền đúng thông tin Code");
            } else if(!ticketnameRegex.test(Name)) {
                res.send("Vui lòng điền đúng thông tin Name");
            } else {
                // Kiểm tra sự trùng lặp của mã Ticket (Code) và tên Ticker (Name) trong cơ sở dữ liệu
                function checkDuplicateTicker(Code, Name, callback) {
                    const sql = 'SELECT COUNT(*) AS count FROM ticker WHERE Code = ? OR Name = ?';
                    db.query(sql, [Code, Name], (err, results) => {
                    if (err) {
                        callback(err, null);
                        return;
                    }
                    const count = results[0].count;
                    callback(null, count > 0);
                    });
                }

                checkDuplicateTicker(Code, Name, (err, isDuplicate) => {
                    if (err) {
                    console.error('Error:', err.message);
                    return;
                    }
                    if (isDuplicate) {
                        res.send("Dữ liệu này đã có.");
                    } else {
                        //Thực hiện insert data base
                        const sql = 'INSERT INTO ticker (Code, Name) VALUES (?, ?)';
                        const values = [Code, Name]; // đặt values cho ticket từ form nhập
                        
                        db.query(sql, values, (err, rs) => {
                            if (err) {
                                console.error("Lỗi khi insert dữ liệu:", err);
                                res.send("Đã xảy ra lỗi khi insert dữ liệu.");
                            } else {
                                console.log("Number of records inserted: " + rs.affectedRows);
                                res.redirect("./list");
                            }
                        })
                    }
                
                })
            }
        
    },
    SearchByName:(req,res)=>{
        let keyword = req.params.keyword;
        if(keyword.length>0){
            const sql = 'SELECT * FROM ticker WHERE Name LIKE ?';
            db.query(sql, [`%keyword%`], (err, rs) => {
                if (err) {
                    console.error("Lỗi khi select dữ liệu:", err);
                    res.send("Đã xảy ra lỗi khi select dữ liệu.");
                } else {
        
                    res.render("./User/index.html",{"users":rs,"keyword":keyword});
                }
            })
        }
    },
    SearchByNameByInput:(req,res)=>{
        let keyword = req.body.keyword;
        console.log(keyword);
        if(keyword.length>0){
            const sql = 'SELECT * FROM ticker WHERE Name LIKE ?';
            db.query(sql, [`%${keyword}%`], (err, rs) => {
                if (err) {
                    console.error("Lỗi khi select dữ liệu:", err);
                    res.send("Đã xảy ra lỗi khi select dữ liệu.");
                } else {
                    console.log(rs);
        
                    res.render("./User/index.html",{"users":rs,"keyword":keyword});
                }
            })
        }
    },
    Delete:(req,res)=>{
        let keyword = req.params.keyword;
        if(keyword.length>0){
            const sql = 'DELETE FROM ticker WHERE id = ?';
            db.query(sql, keyword, (err, rs) => {
                if (err) {
                    console.error("Lỗi khi delete dữ liệu:", err);
                    res.send("Đã xảy ra lỗi khi delete dữ liệu.");
                } else {
                    console.log("Number of records deleted: " + rs.affectedRows);
                    res.redirect("../list");
                }
            })
        }
    },
    Update:(req,res)=>{ 
        let keyword = req.params.keyword;
        if(keyword.length>0){
            const sql = 'SELECT * FROM ticker WHERE id= ?';
            db.query(sql, keyword, (err, rs) => {
                if (err) {
                    console.error("Lỗi khi update dữ liệu:", err);
                    res.send("Đã xảy ra lỗi khi update dữ liệu.");
                } else {
        
                    res.render("./User/update.html",{"users":rs[0]});
                }
            })
        }
    },
    UpdateNew:(req,res)=>{
        let Code = req.body.Code;
        let Name = req.body.Name;
        let keyword = req.params.keyword;

        
        const ticketnameRegex = /^[A-Za-z0-9 ]+$/;

            if(!ticketnameRegex.test(Name)) {
                res.send("Vui lòng điền đúng thông tin Name");
            } else {
                // Kiểm tra sự trùng lặp của mã Ticket (Code) và tên Ticker (Name) trong cơ sở dữ liệu
                function checkDuplicateTicker(Code, Name, callback) {
                    const sql = 'SELECT COUNT(*) AS count FROM ticker WHERE Code = ? OR Name = ?';
                    db.query(sql, [Code, Name], (err, results) => {
                    if (err) {
                        callback(err, null);
                        return;
                    }
                    const count = results[0].count;
                    callback(null, count > 0);
                    });
                }

                checkDuplicateTicker(Code, Name, (err, isDuplicate) => {
                    if (err) {
                    console.error('Error:', err.message);
                    return;
                    }
                    if (isDuplicate) {
                        res.send("Dữ liệu này đã có.");
                    } else {
                        //Thực hiện insert data base
                        const sql = 'UPDATE ticker SET Code=?, Name =? WHERE id= ? ';
                        const values = [Code, Name,keyword]; // đặt values cho ticket từ form nhập
                        
                        db.query(sql, values, (err, rs) => {
                            if (err) {
                                console.error("Lỗi khi update dữ liệu:", err);
                                res.send("Đã xảy ra lỗi khi update dữ liệu.");
                            } else {
                                console.log("Number of records UPDATE: " + rs.affectedRows);
                                res.redirect("../list");
                            }
                        })
                    }
                
                })
            }
        
    },
}