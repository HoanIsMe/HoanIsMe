'use strict';
const express = require("express");
const path = require("path");
const ejs = require("ejs");
const bodyParser = require("body-parser");
const app = express();

//set view engine
app.set("Views", path.join(__dirname, "Views"));
app.set("view engine","ejs");
app.engine("html", ejs.renderFile);
//set use static file
app.use(express.static(path.join(__dirname,"Public")));
//set body parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

var user = require("./Controller/user");
var routes = require("./Api/routes");
routes(app,user);

app.listen(3000, function(){console.log("App started by port 3000")});
